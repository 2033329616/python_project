from distutils.core import setup  
setup(name='Js2py',  #打包后的包文件名  
      version='1.0',    
      description='use js code to compute the tk value',    
      author='David',    
      author_email='2033329616@qq.com',    
      url='https://github.com/2033329616',    
      py_modules=['HandleJs'],   #与前面的新建文件名一致  
) 